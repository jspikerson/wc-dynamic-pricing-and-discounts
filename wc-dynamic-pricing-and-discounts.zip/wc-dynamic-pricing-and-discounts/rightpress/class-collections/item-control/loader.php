<?php

// Exit if accessed directly
defined('ABSPATH') || exit;

// Load class collection files

require_once 'rightpress-item.class.php';
require_once 'rightpress-item-controller.class.php';
